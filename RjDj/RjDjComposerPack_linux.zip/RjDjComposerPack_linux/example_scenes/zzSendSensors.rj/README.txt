This scene uses pd_send to send accelerometer data and screen touches to your
computer. Use the rjutils/get_sensors.pd patch to connect to the phone and
receive data on your computer.
