With kind permission by Andy Farnell and his publisher we are happy to include
an excerpt of: 

"Designing Sound - Practical synthetic sound design for film, games and
interactive media using dataflow"

here. It gives a detailed introduction into working with the RjDj composer's
software (i.e. Pd). Please consider buying the full book, which includes many
more examples and theory. Check out http://aspress.co.uk/ds/

