/*
 *  MouthTracker.cpp
 *  mouthsynth
 *
 *  Created by Marek Bereza on 04/09/2010.
 *  Copyright 2010 Marek Bereza. All rights reserved.
 *
 */

#include "MouthTracker.h"

